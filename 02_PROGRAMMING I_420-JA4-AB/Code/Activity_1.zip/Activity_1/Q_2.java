package Activity_1;

//Project  : Activity_1
//Question : 2
//Author   : BAO, Qingjun
//Date     : 2023/06/07

//2. Write a Java program to print the sum of two numbers. 
//Test Data: 
//74 + 36 
//Expected Output : 
//110

public class Q_2 {
	public static void main(String[] args){
		int num1 = 74;
		int num2 = 36;
		System.out.print(num1 + num2);
	}
}

