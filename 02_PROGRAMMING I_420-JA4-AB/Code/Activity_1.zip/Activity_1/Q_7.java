package Activity_1;

//Project  : Activity_1
//Question : 7
//Author   : BAO, Qingjun
//Date     : 2023/06/07

//7. Write a Java program to print a face. 
//Expected Output
// +"""""+
//[| o o |]
// |  ^  |
// | '-' |
// +-----+

public class Q_7 {
	public static void main(String[] args){
		System.out.println(" +\"\"\"\"\"+");
		System.out.println("[| o o |]");
		System.out.println(" |  ^  |");
		System.out.println(" | '-' |");
		System.out.println(" +-----+");
	}
}

