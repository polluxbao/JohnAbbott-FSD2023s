package Activity_2;

//Project  : Activity_2
//Filename : Q_2.java
//Question : 2
//Author   : BAO, Qingjun
//Date     : 2023/06/08

//2. Write a Java program to compute a specified formula. 
//Specified Formula : 
//4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11)) 
//Expected Output 
//2.9760461760461765

public class Q_2 {
	public static void main(String[] args){
		
		double result = 4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11));

		System.out.println(result);
	}
}
