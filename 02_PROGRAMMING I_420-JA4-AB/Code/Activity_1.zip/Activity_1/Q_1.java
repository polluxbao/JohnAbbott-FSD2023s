package Activity_1;

//Project  : Activity_1
//Question : 1
//Author   : BAO, Qingjun
//Date     : 2023/06/07

//1. Write a Java program to print 'Hello' on screen and your name on a separate line. 
//Expected Output : 
//Hello 
//Alexandra Abramov

public class Q_1 {
	public static void main(String[] args){
		System.out.println("Hello");
		
		String firstName = "Qingjun";
		String lastName = "BAO";

		System.out.println(firstName + " " + lastName);
	}
}
